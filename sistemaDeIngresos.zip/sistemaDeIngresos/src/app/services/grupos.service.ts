import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GruposService {

  public internalEndpoint: string = 'http://localhost:8080/grupos';
  public internalEndpointEntradas: string = 'http://localhost:8080/entradas';

  constructor(private http: HttpClient) {

  }

  traerTodasLasEntradas(): Observable<any> {
    return this.http.get<any>(this.internalEndpointEntradas);
  }

  encontrarEntradaPorId(id: any): Observable<any> {
    return this.http.get<any>(`${this.internalEndpointEntradas}/${id}`);
  };

  borrarEntradaPorId(id: any) {
    return this.http.delete<any>((`${this.internalEndpointEntradas}/${id}`));
  }

  enviarEntrada(body: any): Observable<any> {
    return this.http.post<any>(this.internalEndpointEntradas, body);
  }

  /////////////////////

  traerTodosLosGrupos(): Observable<any> {
    return this.http.get<any>(this.internalEndpoint);
  }

  enviarGrupo(body: any): Observable<any> {
    return this.http.post<any>(this.internalEndpoint, body);
  }

  encontrarGrupoPorId(id: any): Observable<any> {
    return this.http.get<any>(`${this.internalEndpoint}/${id}`);
  };

  borrarGrupoPorId(id: any) {
    return this.http.delete<any>((`${this.internalEndpoint}/${id}`));
  }

  
  
}
