import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BasesComponent } from './paginas/bases/bases.component';
import { EntradaGrupoComponent } from './paginas/entrada-grupo/entrada-grupo.component';
import { IngresarEntradaComponent } from './paginas/ingresar-entrada/ingresar-entrada.component';
import { InicioComponent } from './paginas/inicio/inicio.component';

const routes: Routes = [
  {path: 'inicio' , component: InicioComponent},
  {path: 'entrada-grupo', component: EntradaGrupoComponent},
  {path: 'ingresar-entrada', component: IngresarEntradaComponent},
  {path: 'bases', component: BasesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
