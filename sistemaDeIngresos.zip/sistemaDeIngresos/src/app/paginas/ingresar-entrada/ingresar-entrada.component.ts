import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GruposService } from 'src/app/services/grupos.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-ingresar-entrada',
  templateUrl: './ingresar-entrada.component.html',
  styleUrls: ['./ingresar-entrada.component.css']
})
export class IngresarEntradaComponent implements OnInit {


  constructor(
    private grupoServicio: GruposService,
    private router: Router
  ) { }

  public showGroup: boolean = false;
  public idDeBusqueda: string;
  public usuarioEncontrado: any;
  
  grupoObject: any = {
    'nombre': '',
    'apellido': '',
    'telefono': '',
    'correo': '',
    'edad': '',
    'ocupacion': '',
    'grupo': '',
    'documento': ''
  }


  ngOnInit(): void {

  }

  enviarInformacion() {
    console.log("click enviar informacion");
    console.log("valor del objeto ", this.grupoObject);
    this.grupoServicio.enviarEntrada(this.grupoObject).subscribe(resp => {
      Swal.fire(
        'La entrada ha sido creada con exito!',
        `La entrada ha sido crada con el usuario ${resp.nombre} ${resp.apellido}`,
        'success'
      )
    });
  }

  cancelar() {
    this.router.navigate(['inicio']);
  }

  showRegister() {
    this.showGroup = true;
  }

  enviarId() {
    this.grupoServicio.encontrarEntradaPorId(this.idDeBusqueda).subscribe(resp => {
      Swal.fire(
        'Entrada encontrada',
        `La entrada con el usuario ${resp.nombre} ${resp.apellido} ha sido encontrada`,
        'success'
      );
      this.usuarioEncontrado = resp;
    });
  }

  borrar() {
    this.grupoServicio.borrarEntradaPorId(this.usuarioEncontrado.id).subscribe(resp => {
      Swal.fire(
        'Entrada eliminada',
        'info'
      );
    });
    this.showGroup = false;
    this.usuarioEncontrado = null;
  }

}
