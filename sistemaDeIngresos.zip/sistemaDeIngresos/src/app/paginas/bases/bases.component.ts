import { GruposService } from 'src/app/services/grupos.service';
import { Component, ViewChild, OnInit, AfterViewInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import Swal from 'sweetalert2';

// {
//   "id": 1,
//   "nombre": "Omar",
//   "apellido": "Cuadrado",
//   "telefono": "3103103102",
//   "correo": "OmitarYHelly@gmail.com",
//   "edad": 24,
//   "ocupacion": "Profesor",
//   "grupo": "1",
//   "documento": null,
//   "clasesAsistidas": 4,
//   "clasesTotales": 10,
//   "fecha": "2021-10-16"
// }

@Component({
  selector: 'app-bases',
  templateUrl: './bases.component.html',
  styleUrls: ['./bases.component.css']
})
export class BasesComponent implements OnInit {

  displayedColumns: string[] = [
    'id', 'nombre', 'apellido', 'telefono', 'correo', 'edad',
    'ocupacion', 'grupo', 'documento', 'clasesAsistidas', 'clasesTotales', 'fecha',
    'delete'
  ];
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  displayedColumnsTwo: string[] = [
    'id', 'nombre', 'apellido', 'telefono', 'correo', 'edad',
    'ocupacion', 'grupo', 'documento', 'fecha',
    'delete'
  ];
  dataSourceTwo: MatTableDataSource<any>;
  @ViewChild(MatPaginator) paginatorTwo: MatPaginator;
  @ViewChild(MatSort) sortTwo: MatSort;

  constructor(private gruposService: GruposService) { }

  ngOnInit(): void {
    this.getDatasource();
  }

  getDatasource() {
    this.gruposService.traerTodosLosGrupos().subscribe(resp => {
      this.dataSource = new MatTableDataSource(resp);
    });

    this.gruposService.traerTodasLasEntradas().subscribe(resp => {
      this.dataSourceTwo = new MatTableDataSource(resp); 
    });

    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.dataSourceTwo.paginator = this.paginatorTwo;
      this.dataSourceTwo.sort = this.sortTwo;
    }, 2000);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  applyFilterTwo(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceTwo.filter = filterValue.trim().toLowerCase();

    if (this.dataSourceTwo.paginator) {
      this.dataSourceTwo.paginator.firstPage();
    }
  }

  borrar(rowInformation: any) {
    this.gruposService.borrarGrupoPorId(rowInformation.id).subscribe(resp => {
      Swal.fire(
        'Usuario eliminado',
        `El usuario ${resp.nombre} ${resp.apellido} ha sido eliminado`,
        'info'
      );
      this.getDatasource();
    });
  }

  borrarEntrada(rowInformation: any) {
    this.gruposService.borrarEntradaPorId(rowInformation.id).subscribe(resp => {
      Swal.fire(
        'Entrada eliminada',
        'info'
      );
      this.getDatasource();
    });
  }

}
