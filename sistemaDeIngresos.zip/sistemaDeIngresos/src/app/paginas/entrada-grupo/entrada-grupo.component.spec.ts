import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntradaGrupoComponent } from './entrada-grupo.component';

describe('EntradaGrupoComponent', () => {
  let component: EntradaGrupoComponent;
  let fixture: ComponentFixture<EntradaGrupoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntradaGrupoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntradaGrupoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
