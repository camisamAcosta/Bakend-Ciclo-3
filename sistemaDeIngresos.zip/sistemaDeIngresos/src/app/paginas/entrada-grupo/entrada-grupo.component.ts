import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GruposService } from 'src/app/services/grupos.service';
import Swal from 'sweetalert2';



@Component({
  selector: 'app-entrada-grupo',
  templateUrl: './entrada-grupo.component.html',
  styleUrls: ['./entrada-grupo.component.css']
})
export class EntradaGrupoComponent implements OnInit {

  constructor(
    private grupoServicio: GruposService,
    private router: Router
  ) { }

  public showGroup: boolean = false;
  public idDeBusqueda: string;
  public usuarioEncontrado: any;
  
  grupoObject: any = {
    'nombre': '',
    'apellido': '',
    'telefono': '',
    'correo': '',
    'edad': '',
    'ocupacion': '',
    'grupo': '',
    'clasesAsistidas': '',
    'clasesTotales': '',
    'documento': ''
  }


  ngOnInit(): void {

  }

  enviarInformacion() {
    console.log("click enviar informacion");
    console.log("valor del objeto ", this.grupoObject);
    this.grupoServicio.enviarGrupo(this.grupoObject).subscribe(resp => {
      Swal.fire(
        'El usuario ha sido creado con exito en el grupo!',
        `El usuario ${resp.nombre} ${resp.apellido} ha sido creado`,
        'success'
      )
    });
  }

  cancelar() {
    this.router.navigate(['inicio']);
  }

  showRegister() {
    this.showGroup = true;
  }

  enviarId() {
    this.grupoServicio.encontrarGrupoPorId(this.idDeBusqueda).subscribe(resp => {
      Swal.fire(
        'Usuario encontrado',
        `El usuario ${resp.nombre} ${resp.apellido} ha sido encontrado`,
        'success'
      );
      this.usuarioEncontrado = resp;
    });
  }

  borrar() {
    this.grupoServicio.borrarGrupoPorId(this.usuarioEncontrado.id).subscribe(resp => {
      Swal.fire(
        'Usuario eliminado',
        `El usuario ${resp.nombre} ${resp.apellido} ha sido eliminado`,
        'info'
      );
    });
    this.showGroup = false;
    this.usuarioEncontrado = null;
  }
}
