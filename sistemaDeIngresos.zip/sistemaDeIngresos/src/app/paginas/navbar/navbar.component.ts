import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  entradaGrupo() {
    this.router.navigate(['/entrada-grupo']);
  }

  ingresarEntrada() {
    this.router.navigate(['/ingresar-entrada']);
  }

  basesDeDatos() {
    this.router.navigate(['/bases']);
  }

  inicio() {
    this.router.navigate(['/inicio']);
  }

}
